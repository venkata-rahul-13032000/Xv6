#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char **argv) {
    int file_descriptor, r;
    int case_insensitive = 0;
    int result;
    char *arguments;

    if (argc <= 1) {
        result = uniq(0, case_insensitive, "");
	if (result < 0) {
	    printf(1, "Error: uniq command failed\n");
	}
        exit();
    } else if (argc == 2) {
        if (strcmp(argv[1], "-i") == 0) {
            // Enable case-insensitive search if the -i flag is provided
            case_insensitive = 1;
        } else {
            for (r = 1; r < argc; r++) {
                if (strcmp(argv[r], "-") == 0) {
                    // If filename is "-", read from stdin (0)
                    result = uniq(0, case_insensitive, "");
                } else {
                    if ((file_descriptor = open(argv[r], 0)) < 0) {
                        printf(1, "custom_uniq: cannot open %s\n", argv[r]);
                        exit();
                    }
                    result = uniq(file_descriptor, case_insensitive, "");
                    close(file_descriptor);
                }
            }
	    if (result < 0) {
                printf(1, "Error: uniq command failed\n");
	    }
            exit();
        }
    } else {
        if (strcmp(argv[1], "-i") == 0) {
            // Enable case-insensitive search if the -i flag is provided
            case_insensitive = 1;
        }
        for (r = 2; r < argc; r++) {
            if ((file_descriptor = open(argv[r], 0)) < 0) {
                printf(1, "custom_uniq: cannot open %s\n", argv[r]);
                exit();
            }
	    arguments = argv[1];
            result = uniq(file_descriptor, case_insensitive, arguments);
            close(file_descriptor);
        }
	if (result < 0) {
            printf(1, "Error: uniq command failed\n");
	}
        exit();
    }
}
