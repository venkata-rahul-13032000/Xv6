#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[]) {
  setPolicy(0);
  if (argc < 2) {
    printf(2, "Usage: %s <command1> <arg1> <command2> <arg2> ...\n", argv[0]);
    exit();
  }

  int n = (argc - 1) / 2; // Calculate the number of commands and arguments

  // Test FCFS Scheduling
  printf(1, "Testing FCFS Scheduling\n");

  int cmd_index = 1;

  for (int i = 0; i < n; i++) {
    int pid = fork();

    if (pid == 0) { // Child process
      // Execute the specified command with its arguments
      char *cmd_args[] = { argv[cmd_index], argv[cmd_index + 1], 0 };
      exec(cmd_args[0], cmd_args);
      printf(2, "Failed to execute command: %s\n", cmd_args[0]);
      exit();
    } else if (pid < 0) {
      printf(2, "Fork error\n");
      exit();
    }

    wait(); // Wait for the child to finish

    // Move to the next command and its argument
    cmd_index += 2;
  }

  // Report FCFS Statistics
  statistics();

  exit();
}

