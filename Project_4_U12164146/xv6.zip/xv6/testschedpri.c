#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[]) {
  if (argc < 2) {
    printf(2, "Usage: %s <command1> <arg1> <command2> <arg2> ...\n", argv[0]);
    exit();
  }

  int n = (argc - 1) / 3; // Calculate the number of commands, arguments, and priorities

  setPolicy(1); // Set the scheduling policy to priority-based

  // Test Priority-Based Scheduling
  printf(1, "Testing Priority-Based Scheduling\n");

  int cmd_index = 1;

  for (int i = 0; i < n; i++) {
    int pid = fork();

    if (pid == 0) { // Child process
      // Extract the command, argument, and priority
      char *cmd = argv[cmd_index];
      char *arg = argv[cmd_index + 1];
      int priority = atoi(argv[cmd_index + 2]);

      if (strcmp(cmd, "head_user") == 0 || strcmp(cmd, "uniq_user") == 0) {
        // If command is head_user or uniq_user and no priority is specified, set a lower default priority
        if (priority == 0) {
          priority = 1; // Lower priority
        }
      }

      chpriority(pid, priority); // Set the priority for the process

      char *cmd_args[] = { cmd, arg, 0 };

      // Execute the specified command with its argument
      exec(cmd_args[0], cmd_args);
      printf(2, "Failed to execute command: %s\n", cmd_args[0]);
      exit();
    } else if (pid < 0) {
      printf(2, "Fork error\n");
      exit();
    }

    wait(); // Wait for the child to finish

    // Move to the next command, argument, and priority
    cmd_index += 3;
  }

  // Report Priority-Based Scheduling Statistics
  statistics();

  exit();
}

