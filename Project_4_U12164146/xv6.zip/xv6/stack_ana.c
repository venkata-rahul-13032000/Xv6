#include "types.h"
#include "user.h"

void recursiveFunction(int depth) {
    if (depth == 0) {
        return;
    }

    // Allocate some space on the stack
    int localVar = depth;

    // Print the local variable and depth
    printf(1, "Stack Top: %p, Local Variable: %d, Depth: %d\n", &localVar, localVar, depth);

    // Call the function recursively
    recursiveFunction(depth - 1);
}

int main() {
    // Print a header to identify the program's purpose
    printf(1, "Stack Rearrangement Test Program\n");

    // Demonstrate stack behavior in the new layout
    recursiveFunction(5);

    // Print a message to indicate the end of the program
    printf(1, "Program completed\n");

    // Exit the program
    exit();
}

