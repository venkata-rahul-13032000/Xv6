#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"

int main(int argc, char *argv[])
{
    int rtime;
    int ctime;
    int etime;

    printf(1, "Testing waitx()...\n");

        int pid = fork();
        if(pid == 0) //child process
        {
            exec(argv[1], argv + 1);
            exit();      
        }

        waitx(&rtime,&ctime,&etime);

        printf(1, "--> Running time: %d\n", rtime);
        printf(1, "--> Creation time: %d\n", ctime);
        printf(1, "--> End time: %d\n", etime);

    exit();

    return 0;
}
