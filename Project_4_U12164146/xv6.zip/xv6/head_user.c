#include "types.h"
#include "stat.h"
#include "user.h"

char buffer[512];

void custom_head(int file_descriptor, int num_lines) {
    int index, read_count;
    int line_number, char_count;

    line_number = char_count = 0;
    char line_buffer[512];

    while ((read_count = read(file_descriptor, buffer, sizeof(buffer))) > 0) {
        for (index = 0; index < read_count; index++) {
            if (line_number >= num_lines) {
                return;
            }
            
            if (buffer[index] == '\n') {
                line_number++;
            }

            if (line_number <= num_lines) {
                line_buffer[char_count] = buffer[index];
                char_count++;
                
                if (buffer[index] == '\n') {
                    line_buffer[char_count] = '\0';
                    printf(1, "Line %d: %s", line_number, line_buffer);
                    char_count = 0;
                }
            }
        }
    }
}

int main(int argc, char *argv[]) {
    int i, num_lines;
    int file_descriptor;
    int printed_filename = 0; // Flag to check if filename has been printed

    printf(1, "Executing the custom head command in user mode.\n"); // Print the startup message

    num_lines = 14;

    if (argc <= 1) {
        custom_head(0, num_lines);
        exit();
    }

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-n") == 0) {
            // Check for the -n option
            if (i + 1 < argc && atoi(argv[i + 1]) > 0) {
                num_lines = atoi(argv[i + 1]);
                i++; // Skip the next argument
            } else {
                printf(1, "Invalid option\n");
                exit();
            }
        } else {
            // Open the file and process it
            if ((file_descriptor = open(argv[i], 0)) < 0) {
                printf(1, "Cannot open %s\n", argv[i]);
            } else {
                if (printed_filename) {
                    // If filename has already been printed, add a newline separator
                    printf(1, "\n");
                } else {
                    printed_filename = 1;
                }
                printf(1, "--- %s ---\n", argv[i]); // Print the filename
                custom_head(file_descriptor, num_lines);
                close(file_descriptor);
            }
        }
    }

    exit();
}
