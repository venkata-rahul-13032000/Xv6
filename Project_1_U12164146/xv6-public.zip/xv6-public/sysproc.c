#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

char buffer[512];
char buf[512];


static int
argfd(int n, int *pfd, struct file **pf)
{
  int fd;
  struct file *f;

  if(argint(n, &fd) < 0)
    return -1;
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    return -1;
  if(pfd)
    *pfd = fd;
  if(pf)
    *pf = f;
  return 0;
}

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}


int sys_head(void) {
    int num_lines;
    struct file *filename; 
    int index, read_count;
    int line_number, char_count;

    line_number = char_count = 0;
    char line_buffer[512];

    cprintf("Executing the custom head command in kernel mode.\n"); // Print the startup message
    if (argfd(0, 0, &filename) < 0 || argint(1, &num_lines) < 0) {
        return -1; // Argument validation failed
    }
    while ((read_count = fileread(filename, buffer, sizeof(buffer))) > 0) {
        for (index = 0; index < read_count; index++) {
            if (line_number >= num_lines) {
                return 0;
            }

            if (buffer[index] == '\n') {
                line_number++;
            }

            if (line_number <= num_lines) {
                line_buffer[char_count] = buffer[index];
                char_count++;

                if (buffer[index] == '\n') {
                    line_buffer[char_count] = '\0';
		    cprintf("Line %d: %s", line_number, line_buffer);
                    char_count = 0;
                }
            }
        }
    }
    fileclose(filename);
    return 0;
}


int strcasecmp(const char *s1, const char *s2) {
    while (*s1 && ((*s1 | 32) == (*s2 | 32))) {
        s1++;
        s2++;
    }
    return (*(unsigned char *)s1 | 32) - (*(unsigned char *)s2 | 32);
}

int sys_uniq(void) {
    int case_insensitive;
    struct file *filename;
    char *arg; 
    int total = 0, i, k, p, q, index = 0, m = 0, lines = 0, chars = 0, char_count = 0, count1 = 0;
    char pilot[100];
    char *output[100];
    int repeat[100];

    cprintf("Executing the custom uniq command in kernel mode.\n"); // Print the startup message
    if (argfd(0, 0, &filename) < 0 || argint(1, &case_insensitive) < 0 || argstr(2, &arg) < 0) {
        return -1; // Argument validation failed
    }
    while ((chars = fileread(filename, buf, sizeof(buf))) > 0) {
        for (i = 0; i < chars; i++) {
            if (buf[i] == '\n') {
                lines++;
            }
        }

        for (i = 0; buf[i] != '\n'; i++) {
            char_count++;
            pilot[i] = buf[i];
        }

        pilot[i] = '\0';
        repeat[0] = 1;
        output[0] = kalloc();
	if (output[index] == 0) {
            // Handle allocation failure
            cprintf("Memory allocation failed\n");
            return -1;
        }
        for (i = 0; i < char_count + 1; i++) {
            output[index][i] = pilot[i];
        }
        output[index][i] = '\0';
        k = i;

        while (total < lines - 1) {
            total++;
            count1 = 0;
            for (i = k; buf[i] != '\n'; i++) {
                count1++;
                pilot[m++] = buf[i];
            }
            pilot[m] = '\0';
            k = k + count1 + 1;
            m = 0;

            // Compare strings with or without case-insensitivity based on the flag
            if (case_insensitive) {
                if (strcasecmp(output[index], pilot) != 0) {
                    index = index + 1;
                    output[index] = kalloc();
		    if (output[index] == 0) {
                        // Handle allocation failure
                        cprintf("Memory allocation failed\n");
                        return -1;
                    }
                    for (p = 0; p < count1; p++) {
                        output[index][p] = pilot[p];
                    }
                    output[index][p] = '\0';
                    repeat[index] = 1;
                } else {
                    repeat[index] = repeat[index] + 1;
                }
            } else {
                if (strncmp(output[index], pilot, strlen(pilot)) != 0) {
                    index = index + 1;
                    output[index] = kalloc();
		    if (output[index] == 0) {
                        // Handle allocation failure
                        cprintf("Memory allocation failed\n");
                        return -1;
                    }
                    for (p = 0; p < count1; p++) {
                        output[index][p] = pilot[p];
                    }
                    output[index][p] = '\0';
                    repeat[index] = 1;
                } else {
                    repeat[index] = repeat[index] + 1;
                }
            }
        }
    }

    if (strncmp(arg, "-c", 2) == 0 || strncmp(arg, "-C", 2) == 0) {
        for (q = 0; q < index + 1; q++) {
            cprintf("%d %s \n", repeat[q], output[q]);
        }
    } else if (strncmp(arg, "-d", 2) == 0 || strncmp(arg, "-D", 2) == 0) {
        for (q = 0; q < index + 1; q++) {
            if (repeat[q] > 1) {
                cprintf("%s \n", output[q]);
            }
        }
    } else {
        for (q = 0; q < index + 1; q++) {
            cprintf("%s \n", output[q]);
        }
    }

    for (q = 0; q < index + 1; q++) {
        kfree(output[q]);
    }
    return 0;
}
