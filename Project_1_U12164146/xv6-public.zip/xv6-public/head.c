#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[]) {
    int i, num_lines;
    int file_descriptor;
    int printed_filename = 0; // Flag to check if filename has been printed

    num_lines = 14;

    if (argc <= 1) {
        head(0, num_lines);
        exit();
    }

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-n") == 0) {
            // Check for the -n option
            if (i + 1 < argc && atoi(argv[i + 1]) > 0) {
                num_lines = atoi(argv[i + 1]);
                i++; // Skip the next argument
            } else {
                printf(1, "Invalid option\n");
                exit();
            }
        } else {
            // Open the file and process it
            if ((file_descriptor = open(argv[i], 0)) < 0) {
                printf(1, "Cannot open %s\n", argv[i]);
            } else {
                if (printed_filename) {
                    // If filename has already been printed, add a newline separator
                    printf(1, "\n");
                } else {
                    printed_filename = 1;
                }
                printf(1, "--- %s ---\n", argv[i]); // Print the filename
                int result = head(file_descriptor, num_lines);
		close(file_descriptor);
		if (result < 0) {
		    printf(1, "Error: head command failed\n");
		    exit();
		}
            }
        }
    }
    exit();
}
