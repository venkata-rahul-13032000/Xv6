#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[]){
    
    int i;
    printf(1,"name \t pid \t state \t\t ctime \t rtime\n");
    if (argc <= 1) {
        ps("");
        exit();
    }
    for (i = 1; i < argc; i++) {
        ps(argv[i]);
    }
    exit();
}
